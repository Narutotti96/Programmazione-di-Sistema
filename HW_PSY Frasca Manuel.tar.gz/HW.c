#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#include <unistd.h>
#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>

#define BUFFER_ERROR (msg_t*)NULL

typedef struct msg {
    void* content;
    struct msg* (*msg_init)(void*);
    void (*msg_destroy)(struct msg*);
    struct msg* (*msg_copy)(struct msg*);
} msg_t;

msg_t* msg_init_string(void* content);
void msg_destroy_string(msg_t* msg);
msg_t* msg_copy_string(msg_t* msg);

msg_t* msg_init_string(void* content) {
    msg_t* new_msg = (msg_t*)malloc(sizeof(msg_t));
    char* string = (char*)content;
    char* new_content = (char*)malloc(strlen(string) + 1);
    strcpy(new_content, string);
    new_msg->content = new_content;
    new_msg->msg_init = msg_init_string;
    new_msg->msg_destroy = msg_destroy_string;
    new_msg->msg_copy = msg_copy_string;
    return new_msg;
}

void msg_destroy_string(msg_t* msg) {
    free(msg->content);
    free(msg);
}

msg_t* msg_copy_string(msg_t* msg) {
    return msg->msg_init(msg->content);
}

typedef struct buffer {
    msg_t** buffer;
    int head;
    int tail;
    int maxsize;
    sem_t mutex;
    sem_t non_empty;
    sem_t non_full;
    int running;
} buffer_t;

buffer_t* buffer_init(unsigned int maxsize) {
    buffer_t* buffer = (buffer_t*)malloc(sizeof(buffer_t));
    buffer->buffer = (msg_t**)malloc(maxsize * sizeof(msg_t*));
    buffer->maxsize = maxsize;
    buffer->head = 0;
    buffer->tail = 0;
    sem_init(&buffer->mutex, 0, 1);
    sem_init(&buffer->non_empty, 0, 0);
    sem_init(&buffer->non_full, 0, maxsize);
    buffer->running = 1;
    return buffer;
}

void buffer_destroy(buffer_t* buffer) {
    for (int i = 0; i < buffer->maxsize; i++) {
        if (buffer->buffer[i] != NULL) {
            buffer->buffer[i]->msg_destroy(buffer->buffer[i]);
        }
    }
    free(buffer->buffer);
    sem_destroy(&buffer->mutex);
    sem_destroy(&buffer->non_empty);
    sem_destroy(&buffer->non_full);
    free(buffer);
}

msg_t* put_bloccante(buffer_t* buffer, msg_t* msg) {
    sem_wait(&buffer->non_full);
    sem_wait(&buffer->mutex);
    msg_t* old_msg = buffer->buffer[buffer->head];
    buffer->buffer[buffer->head] = msg->msg_copy(msg);
    buffer->head = (buffer->head + 1) % buffer->maxsize;
    sem_post(&buffer->mutex);
    sem_post(&buffer->non_empty);
    return old_msg;
}

msg_t* put_non_bloccante(buffer_t* buffer, msg_t* msg) {
    if (sem_trywait(&buffer->non_full) == 0) {
        sem_wait(&buffer->mutex);
        msg_t* old_msg = buffer->buffer[buffer->head];
        if (old_msg != NULL) {
            old_msg->msg_destroy(old_msg);
        }
        buffer->buffer[buffer->head] = msg->msg_copy(msg);
        buffer->head = (buffer->head + 1) % buffer->maxsize;
        sem_post(&buffer->mutex);
        sem_post(&buffer->non_empty);
        return BUFFER_ERROR;
    } else {
        return NULL; // Buffer pieno, operazione non riuscita
    }
}

msg_t* get_bloccante(buffer_t* buffer) {
    sem_wait(&buffer->non_empty);
    sem_wait(&buffer->mutex);
    msg_t* msg = buffer->buffer[buffer->tail];
    buffer->buffer[buffer->tail] = NULL;
    buffer->tail = (buffer->tail + 1) % buffer->maxsize;
    sem_post(&buffer->mutex);
    sem_post(&buffer->non_full);
    return msg;
}

msg_t* get_non_bloccante(buffer_t* buffer) {
    if (sem_trywait(&buffer->non_empty) == 0) {
        sem_wait(&buffer->mutex);
        msg_t* msg = buffer->buffer[buffer->tail];
        if (msg != NULL) {
            buffer->buffer[buffer->tail] = NULL;
            buffer->tail = (buffer->tail + 1) % buffer->maxsize;
        }
        sem_post(&buffer->mutex);
        sem_post(&buffer->non_full);
        return msg;
    } else {
        return NULL; // Buffer vuoto, operazione non riuscita
    }
}


int quit = 0;
pthread_mutex_t quit_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t quit_cond = PTHREAD_COND_INITIALIZER;

void* producer(void* arg) {
    buffer_t* buffer = (buffer_t*)arg;
    char input[100];
    while (1) {
        sleep(1);
        printf("Inserisci un messaggio da Inviare al Consumatore (o premi 'quit' per terminare): ");
        fgets(input, sizeof(input), stdin);
        input[strcspn(input, "\n")] = '\0';

        if (strcmp(input, "quit") == 0) {
            pthread_mutex_lock(&quit_mutex);
            buffer->running=0;
            quit=1;
            pthread_cond_signal(&quit_cond);
            pthread_mutex_unlock(&quit_mutex);
            break;
        }

        msg_t* msg = msg_init_string(input);
        msg_t* old_msg = put_bloccante(buffer, msg);
        if (old_msg != NULL) {
            old_msg->msg_destroy(old_msg);
        }
    }
    return NULL;
}


void* consumer(void* arg) {
    buffer_t* buffer = (buffer_t*)arg;
    while (1) {
        msg_t* msg = get_bloccante(buffer);
        if (msg != NULL) {
            char* content = (char*)msg->content;
            printf("Messaggio Ricevuto dal Produttore: %s\n", content);
            msg->msg_destroy(msg);
        }

        pthread_mutex_lock(&quit_mutex);
        if (!buffer->running) {
            pthread_mutex_unlock(&quit_mutex);
            break;
        }
        pthread_mutex_unlock(&quit_mutex);

    }
    return NULL;
}

int main() {
    buffer_t* buffer = buffer_init(10);
    pthread_t producer_thread, consumer_thread;
    pthread_create(&producer_thread, NULL, producer, buffer);
    pthread_create(&consumer_thread, NULL, consumer, buffer);

    pthread_mutex_lock(&quit_mutex);
    while (quit != 1) {
        pthread_cond_wait(&quit_cond, &quit_mutex);
    }
    pthread_mutex_unlock(&quit_mutex);

    pthread_cancel(producer_thread);
    pthread_cancel(consumer_thread);
    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);

    buffer_destroy(buffer);

    return 0;
} 