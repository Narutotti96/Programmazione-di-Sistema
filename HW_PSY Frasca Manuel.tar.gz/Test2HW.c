#include <stdio.h>
#include <stdlib.h>
#include <CUnit/Basic.h>
#include <CUnit/CUnit.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

typedef struct msg {
    void* content;
} msg_t;

typedef struct buffer {
    msg_t* buffer;
    sem_t mutex;
    sem_t full;
    sem_t empty;
} buffer_t;

buffer_t* buffer_init() {
    buffer_t* buffer = (buffer_t*)malloc(sizeof(buffer_t));
    buffer->buffer = NULL;
    sem_init(&buffer->mutex, 0, 1);
    sem_init(&buffer->full, 0, 0);
    sem_init(&buffer->empty, 0, 1);
    return buffer;
}

void buffer_destroy(buffer_t* buffer) {
    sem_destroy(&buffer->mutex);
    sem_destroy(&buffer->full);
    sem_destroy(&buffer->empty);
    free(buffer);
}

void put_buffer(buffer_t* buffer, msg_t* msg) {
    sem_wait(&buffer->empty);
    sem_wait(&buffer->mutex);
    buffer->buffer = msg;
    sem_post(&buffer->mutex);
    sem_post(&buffer->full);
}

msg_t* get_buffer(buffer_t* buffer) {
    sem_wait(&buffer->full);
    sem_wait(&buffer->mutex);
    msg_t* msg = buffer->buffer;
    buffer->buffer = NULL;
    sem_post(&buffer->mutex);
    sem_post(&buffer->empty);
    return msg;
}

void* consumer(void* arg) {
    buffer_t* buffer = (buffer_t*)arg;
    msg_t* msg = get_buffer(buffer);
    // Consuma il messaggio bloccante
    CU_ASSERT_PTR_NOT_NULL(msg);
    CU_ASSERT_STRING_EQUAL((char*)msg->content, "GO MSG");
    free(msg);
    return NULL;
}

void test_scenario() {
    // Creazione del buffer vuoto
    buffer_t* buffer = buffer_init();

    // Creazione del consumatore
    pthread_t consumer_thread;
    pthread_create(&consumer_thread, NULL, consumer, buffer);

    // Verifica che il consumatore sia bloccato
    sleep(1);  // Attendi un po' per assicurarsi che il consumatore sia bloccato

    // Deposita un messaggio nel buffer vuoto
    msg_t* msg = (msg_t*)malloc(sizeof(msg_t));
    msg->content = "GO MSG";
    put_buffer(buffer, msg);

    // Attendi la terminazione del consumatore
    pthread_join(consumer_thread, NULL);

    // Verifica che il buffer sia nuovamente vuoto
    CU_ASSERT_PTR_NULL(buffer->buffer);

    buffer_destroy(buffer);
}

int main() {
    // Inizializzazione del CUnit
    if (CUE_SUCCESS != CU_initialize_registry()) {
        return CU_get_error();
    }

    // Creazione del test suite
    CU_pSuite pSuite = CU_add_suite("Test Suite", NULL, NULL);
    if (NULL == pSuite) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    // Aggiunta del test al test suite
    if (NULL == CU_add_test(pSuite, "Test scenario", test_scenario)) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    // Esecuzione dei test
    CU_basic_set_mode(CU_BRM_VERBOSE);
    CU_basic_run_tests();
    CU_cleanup_registry();

    return CU_get_error();
}
