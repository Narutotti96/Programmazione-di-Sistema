Frasca Manuel 

Per la scrittura del codice è stato usato l’IDE Eclipse C/C++ in un sistema Linux Ubuntu 22.04.2, per i test CUnit 2.1-3

All'interno di questo file sono presenti il file HW.c che è il file principale dove sono implementate tutte le funzioni. Gli altri due file invece sono i test richiesti. Il tutto è stato svolto in linguaggio C.
